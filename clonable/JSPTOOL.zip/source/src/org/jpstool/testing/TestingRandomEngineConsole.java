package org.jpstool.testing;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Random;

import org.jpstool.main.LoadWordPlainText;
import org.jpstool.main.LoopMechanic;
import org.jpstool.main.PickUpWordEngineRandom;
import org.jpstool.main.TimerLoopMechanic;
import org.jpstool.main.WordItem;
import org.junit.Test;

public class TestingRandomEngineConsole {

	@Test
	public void test() {

	}

}
