package org.jpstool.testing;

import org.junit.Test;

public class TestingFlashResultFrame {

	@Test
	public void test() throws InterruptedException {
		float a = 33;
		float b = 201;

		System.out.println((a / b) * 100);
	}

}
