package org.jpstool.main;

import java.util.List;

public interface PickupWordEnigne {
	public WordItem pickUpWord(List<WordItem> listWordItem);
}
