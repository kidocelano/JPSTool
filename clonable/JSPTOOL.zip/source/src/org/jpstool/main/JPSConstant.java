package org.jpstool.main;

public class JPSConstant {
	public static final String CONST_FILE_PATH_PROFILE = "profile.jps";
	public static final String CONST_LINE_SEPARATOR = System.getProperty("line.separator");
}
