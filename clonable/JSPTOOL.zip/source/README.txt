 ▄▄▄██▀▀▀██████  ██▓███     ▄▄▄█████▓ ▒█████   ▒█████   ██▓    
   ▒██ ▒██    ▒ ▓██░  ██▒   ▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    
   ░██ ░ ▓██▄   ▓██░ ██▓▒   ▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    
▓██▄██▓  ▒   ██▒▒██▄█▓▒ ▒   ░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    
 ▓███▒ ▒██████▒▒▒██▒ ░  ░     ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒
 ▒▓▒▒░ ▒ ▒▓▒ ▒ ░▒▓▒░ ░  ░     ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░
 ▒ ░▒░ ░ ░▒  ░ ░░▒ ░            ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░
 ░ ░ ░ ░  ░  ░  ░░            ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   
 ░   ░       ░                           ░ ░      ░ ░      ░  ░

Advanced, feature, benefits of my JSP Tool:
* Release as NDT License (Basically, It's free. But if my tool is your inspiration, you can buy me a vitamin or fruit juice).
* Based on the powerful PL is JAVA.
* Easy to expandable component like write your plugin if you like.
* Standalone and independent.
* Supported by NDT.